import { motion } from 'framer-motion';
import ProjectCard from '../components/ProjectCard';

export default function Projects() {
  const projects = [
    {
      title: '야구 데이터 분석 서비스',
      description: '야구 기록 기반 MVP 예측, 커뮤니티 기능 제공',
      link: 'https://github.com/ManiacMemories/baseball-project',
    },
    {
      title: '포트폴리오 웹사이트',
      description: 'React + Tailwind 기반 스크롤형 개인 웹사이트',
      link: '#',
    },
  ];

  return (
    <motion.div
    className="max-w-4xl px-6"
  initial={{ opacity: 0, y: 30 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true }}
  transition={{ duration: 0.6 }}
>


      <h1 className="text-5xl font-bold mb-10 text-center">📁 Projects</h1>
      <div className="grid gap-8 md:grid-cols-2">
        {projects.map((proj, i) => (
          <ProjectCard
            key={i}
            title={proj.title}
            description={proj.description}
            link={proj.link}
          />
        ))}
      </div>
    </motion.div>
  );
}
import { motion } from 'framer-motion';
import {
  FaJava,
  FaReact,
  FaHtml5,
  FaCss3Alt,
  FaJs,
  FaGithub,
  FaDocker,
} from 'react-icons/fa';
import { SiSpring, SiTailwindcss, SiMysql, SiFigma } from 'react-icons/si';

const skills = [
  { name: 'Java', icon: <FaJava className="text-orange-500" /> },
  { name: 'Spring Boot', icon: <SiSpring className="text-green-600" /> },
  { name: 'React', icon: <FaReact className="text-sky-500" /> },
  { name: 'JavaScript', icon: <FaJs className="text-yellow-400" /> },
  { name: 'MySQL', icon: <SiMysql className="text-blue-700" /> },
  { name: 'HTML5', icon: <FaHtml5 className="text-orange-600" /> },
  { name: 'CSS3', icon: <FaCss3Alt className="text-blue-500" /> },
  { name: 'Tailwind', icon: <SiTailwindcss className="text-cyan-400" /> },
  { name: 'GitHub', icon: <FaGithub className="text-black" /> },
  { name: 'Docker', icon: <FaDocker className="text-blue-500" /> },
  { name: 'Figma', icon: <SiFigma className="text-pink-500" /> },
];

export default function Skills() {
  return (
    <motion.div
      className="max-w-4xl mx-auto px-6 text-center"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <h1 className="text-5xl font-bold mb-8">🛠️ Skills</h1>
      <p className="text-lg text-gray-600 mb-10">
        제가 주로 사용하는 기술 스택입니다.
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
        {skills.map(({ name, icon }, idx) => (
          <div
            key={idx}
            className="flex flex-col items-center space-y-2 bg-gray-100 rounded-xl py-6 shadow hover:scale-105 transition"
          >
            <div className="text-4xl">{icon}</div>
            <div className="text-sm font-medium">{name}</div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

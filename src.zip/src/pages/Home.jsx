import { motion } from 'framer-motion';

export default function Home() {
  return (
    <motion.div
      className="text-center px-6"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <h1 className="text-6xl md:text-7xl font-bold tracking-tight mb-6">
        안녕하세요<br />
        <span className="text-primary">ManiacMemories</span>입니다.
      </h1>
      <p className="text-xl text-gray-600 max-w-2xl mx-auto">
        React, Spring 기반의 웹서비스를 개발합니다. 사용자가 편하게 느끼는 UI/UX를 만듭니다.
      </p>
    </motion.div>
  );
}
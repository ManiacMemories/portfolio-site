import { motion } from 'framer-motion';
export default function Contact() {
  return (
    <motion.div
    className="max-w-2xl text-center px-6"
  initial={{ opacity: 0, y: 30 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true }}
  transition={{ duration: 0.6 }}
>

      <h1 className="text-5xl font-bold mb-6">📞 Contact</h1>
      <p className="text-lg text-gray-600">
        궁금한 점이 있다면 언제든지 연락 주세요!<br />
        이메일: <a href="mailto:your@email.com" className="text-blue-600 underline">your@email.com</a>
      </p>
    </motion.div>
  );
}

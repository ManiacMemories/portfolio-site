// src/pages/About.jsx
export default function About() {
  return (
    <div className="max-w-2xl text-center px-6">
      <h1 className="text-5xl font-bold mb-6">🙋‍♂️ About Me</h1>
      <p className="text-lg text-gray-600 leading-relaxed">
        컴퓨터공학을 전공하고 웹 개발에 몰입하고 있는 주니어 개발자입니다.<br />
        현재 Java, Spring, React, MySQL, Docker 등을 공부하고 있으며,<br />
        데이터를 기반으로 한 야구 웹 프로젝트를 진행하고 있어요.
      </p>
    </div>
  );
}

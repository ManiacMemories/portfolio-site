export default function ProjectCard({ title, description, link }) {
  return (
    
    <div className="border rounded-lg p-6 shadow-md hover:shadow-xl transition">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      {link && (
        <a
          href={link}
          className="text-blue-600 hover:underline"
          target="_blank"
          rel="noopener noreferrer"
        >
          자세히 보기 →
        </a>
      )}
    </div>
  );
}
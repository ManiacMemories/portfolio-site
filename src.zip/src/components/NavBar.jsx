import { useState } from 'react';

export default function NavBar({ activeSection, onNavClick }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const sections = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'skills', label: 'Skills' },
    { id: 'projects', label: 'Projects' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleClick = (id) => {
    onNavClick(id);
    setMenuOpen(false); // 메뉴 닫기
  };

  return (
    <header className="fixed top-0 left-0 w-full bg-white shadow z-50">
      <nav className="container mx-auto flex justify-between items-center px-6 py-4">
        <div className="text-xl font-bold">MyPortfolio</div>

        {/* 데스크탑 메뉴 */}
        <div className="hidden md:flex space-x-6">
          {sections.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => handleClick(id)}
              className={`transition font-medium ${
                activeSection === id
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-blue-500'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* 모바일 메뉴 버튼 */}
        <button
          className="md:hidden text-2xl"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          ☰
        </button>
      </nav>

      {/* 모바일 메뉴 드롭다운 */}
      {menuOpen && (
        <div className="md:hidden bg-white shadow px-6 py-4 space-y-4">
          {sections.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => handleClick(id)}
              className={`block w-full text-left transition font-medium ${
                activeSection === id
                  ? 'text-blue-600'
                  : 'text-gray-700 hover:text-blue-500'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}